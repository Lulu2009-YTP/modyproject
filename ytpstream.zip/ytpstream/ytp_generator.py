import random
import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx, TextClip, CompositeVideoClip
import os

class ExtendedYTPGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("Extended YTP Generator with Scrambling")

        # File selection button
        self.select_button = tk.Button(root, text="Select Video", command=self.select_file)
        self.select_button.pack(pady=10)

        # Clip count input
        self.clip_count_label = tk.Label(root, text="Number of Clips:")
        self.clip_count_label.pack()
        self.clip_count_entry = tk.Entry(root)
        self.clip_count_entry.insert(0, "10")
        self.clip_count_entry.pack(pady=5)

        # Scramble checkbox
        self.scramble_var = tk.IntVar()
        self.scramble_checkbox = tk.Checkbutton(root, text="Enable Scrambling", variable=self.scramble_var)
        self.scramble_checkbox.pack(pady=5)

        # Generate button
        self.generate_button = tk.Button(root, text="Generate YTP", command=self.generate_ytp)
        self.generate_button.pack(pady=10)

        # Label for status
        self.status_label = tk.Label(root, text="No video selected")
        self.status_label.pack(pady=20)

        self.video_file = None

    def select_file(self):
        self.video_file = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
        if self.video_file:
            self.status_label.config(text="Selected: " + os.path.basename(self.video_file))
        else:
            self.status_label.config(text="No video selected")

    def generate_ytp(self):
        if not self.video_file:
            self.status_label.config(text="Please select a video file first")
            return

        # Load the selected video
        video_clip = VideoFileClip(self.video_file)

        # Get the user-specified number of clips
        try:
            num_clips = int(self.clip_count_entry.get())
        except ValueError:
            num_clips = 10  # Default to 10 clips if input is invalid

        # Split video into random short clips
        duration = video_clip.duration
        clips = []
        for _ in range(num_clips):
            start_time = random.uniform(0, duration - 2)  # Random start time
            clip_duration = random.uniform(0.5, 1.5)  # Random clip duration (between 0.5 and 1.5 seconds)
            clip = video_clip.subclip(start_time, start_time + clip_duration)

            # Apply random effects
            clip = self.apply_random_effects(clip)

            # Scramble the clip if the option is selected
            if self.scramble_var.get():
                clip = self.scramble_clip(clip)

            # Optionally add random text overlays
            if random.choice([True, False]):
                clip = self.add_random_text_overlay(clip)

            clips.append(clip)

        # Concatenate all clips into one video
        final_clip = concatenate_videoclips(clips)

        # Save the result
        output_file = "ytp_output_extended_scramble.mp4"
        final_clip.write_videofile(output_file, codec="libx264")

        self.status_label.config(text="YTP generated: " + output_file)

    def apply_random_effects(self, clip):
        """Apply random video effects to a clip."""
        # Random speed change
        if random.choice([True, False]):
            clip = clip.fx(vfx.speedx, random.uniform(0.5, 2.0))  # Speed up/down
        # Random rotation
        if random.choice([True, False]):
            clip = clip.rotate(random.choice([90, 180, 270]))
        # Random mirroring
        if random.choice([True, False]):
            clip = clip.fx(vfx.mirror_x)
        # Random zoom
        if random.choice([True, False]):
            clip = clip.resize(1 + random.uniform(0.01, 0.1))  # Slight zoom in
        # Random blur effect
        if random.choice([True, False]):
            clip = clip.fx(vfx.gaussian_blur, random.uniform(1.0, 5.0))
        # Random color adjustment
        if random.choice([True, False]):
            clip = clip.fx(vfx.colorx, random.uniform(0.5, 1.5))  # Adjust brightness

        # Random cropping
        if random.choice([True, False]):
            x1 = random.randint(0, int(clip.w * 0.5))
            y1 = random.randint(0, int(clip.h * 0.5))
            x2 = clip.w - random.randint(0, int(clip.w * 0.5))
            y2 = clip.h - random.randint(0, int(clip.h * 0.5))
            clip = clip.crop(x1=x1, y1=y1, x2=x2, y2=y2)

        return clip

    def scramble_clip(self, clip):
        """Scramble the video clip by breaking it into smaller parts and shuffling them."""
        subclip_duration = random.uniform(0.1, 0.5)  # Duration of each sub-clip
        duration = clip.duration
        subclips = []

        # Create subclips by breaking the clip into smaller parts
        for start_time in range(0, int(duration), int(subclip_duration * 1000)):
            if start_time + subclip_duration * 1000 <= duration * 1000:
                subclip = clip.subclip(start_time / 1000, (start_time + subclip_duration) / 1000)
                subclips.append(subclip)

        # Shuffle the subclips randomly
        random.shuffle(subclips)

        # Concatenate the shuffled subclips back together
        scrambled_clip = concatenate_videoclips(subclips)

        return scrambled_clip

    def add_random_text_overlay(self, clip):
        """Add a random text overlay to the video clip."""
        random_text = random.choice(["LOL", "WTF", "ROFL", "OMG", "Poop!", "!!!"])
        text_clip = TextClip(random_text, fontsize=70, color='white', stroke_color='black', stroke_width=2)
        text_clip = text_clip.set_position(('center', 'bottom')).set_duration(clip.duration)
        return CompositeVideoClip([clip, text_clip])

if __name__ == "__main__":
    root = tk.Tk()
    app = ExtendedYTPGenerator(root)
    root.mainloop()
