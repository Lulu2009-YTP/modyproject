import random
import os
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox

# Function to scramble video
def scramble_video(input_video_path, output_video_path):
    clip = VideoFileClip(input_video_path)
    
    # Split video into segments (5 random chunks)
    segments = []
    duration = clip.duration
    segment_duration = duration / 20

    for i in range(5):
        start_time = random.uniform(0, duration - segment_duration)
        end_time = start_time + segment_duration
        segment = clip.subclip(start_time, end_time)
        
        # Randomly apply effects: reverse, speed up, slow down
        if random.choice([True, False]):
            segment = segment.fx(vfx.time_mirror)
        if random.choice([True, False]):
            segment = segment.fx(vfx.speedx, factor=random.uniform(0.5, 2.0))
        
        segments.append(segment)

    scrambled_clip = concatenate_videoclips(segments)
    scrambled_clip.write_videofile(output_video_path, codec="libx264")

    clip.close()
    scrambled_clip.close()

# Function to select input video
def select_video():
    input_video_path = filedialog.askopenfilename(title="Select a Video File", filetypes=[("MP4 Files", "*.mp4"), ("All Files", "*.*")])
    if input_video_path:
        input_var.set(input_video_path)

# Function to select output path
def select_output_path():
    output_video_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 Files", "*.mp4")])
    if output_video_path:
        output_var.set(output_video_path)

# Function to run the scramble
def run_scramble():
    input_path = input_var.get()
    output_path = output_var.get()
    if not input_path or not output_path:
        messagebox.showerror("Error", "Please select both input and output paths.")
        return

    scramble_video(input_path, output_path)
    messagebox.showinfo("Success", f"Video scrambled and saved to {output_path}")

# Setup GUI with Tkinter
root = tk.Tk()
root.title("YTP Scramble Generator")

input_var = tk.StringVar()
output_var = tk.StringVar()

# Input video section
tk.Label(root, text="Input Video").grid(row=0, column=0, padx=10, pady=10)
tk.Entry(root, textvariable=input_var, width=40).grid(row=0, column=1)
tk.Button(root, text="Browse", command=select_video).grid(row=0, column=2)

# Output video section
tk.Label(root, text="Output Video").grid(row=1, column=0, padx=10, pady=10)
tk.Entry(root, textvariable=output_var, width=40).grid(row=1, column=1)
tk.Button(root, text="Browse", command=select_output_path).grid(row=1, column=2)

# Run button
tk.Button(root, text="Scramble Video", command=run_scramble, width=20).grid(row=2, column=1, pady=20)

# Start the Tkinter event loop
root.mainloop()
