import os
import random
import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, vfx, afx

# Function to apply random effects to the video
def apply_random_effects(video):
    effects = [vfx.mirror_x, vfx.time_mirror, vfx.lum_contrast, vfx.blackwhite]
    audio_effects = [afx.audio_fadein, afx.audio_fadeout, afx.audio_normalize]
    
    # Apply random video effect
    video_effect = random.choice(effects)
    edited_video = video_effect(video)
    
    # Apply random audio effect
    audio_effect = random.choice(audio_effects)
    edited_video = edited_video.fx(audio_effect, 2)  # 2 seconds fade effect
    
    return edited_video

# Function to process video
def generate_ytp():
    video_path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4;*.avi;*.mov")])
    if not video_path:
        return

    # Load video file
    video = VideoFileClip(video_path)

    # Apply random effects
    edited_video = apply_random_effects(video)

    # Save the new video file
    output_path = os.path.join(os.path.dirname(video_path), "ytp_output.mp4")
    edited_video.write_videofile(output_path, codec="libx264")

    status_label.config(text=f"YTP Generated: {output_path}")

# Create the GUI application
root = tk.Tk()
root.title("YTP Generator 2011 Style")

frame = tk.Frame(root)
frame.pack(padx=20, pady=20)

title_label = tk.Label(frame, text="YTP Generator", font=("Helvetica", 16))
title_label.pack()

generate_button = tk.Button(frame, text="Generate YTP", command=generate_ytp)
generate_button.pack(pady=10)

status_label = tk.Label(frame, text="", font=("Helvetica", 12))
status_label.pack()

# Start the GUI event loop
root.mainloop()
