import tkinter as tk
from tkinter import filedialog, messagebox
from moviepy.editor import VideoFileClip, concatenate_videoclips
import random

# Function to scramble the video by cutting into random clips
def scramble_video(input_path, output_path):
    try:
        # Load the video
        video = VideoFileClip(input_path)
        
        # Scramble parameters
        clip_duration = random.uniform(0.5, 2.0)  # Random clip length between 0.5s and 2.0s
        total_duration = video.duration
        clip_list = []

        # Generate random clips from the video
        while sum([clip.duration for clip in clip_list]) < total_duration:
            start_time = random.uniform(0, total_duration - clip_duration)
            clip = video.subclip(start_time, min(start_time + clip_duration, total_duration))
            clip_list.append(clip)

        # Concatenate the scrambled clips
        scrambled_video = concatenate_videoclips(clip_list)
        scrambled_video.write_videofile(output_path, codec='libx264')
        
        messagebox.showinfo("Success", "Video scrambled and saved successfully!")
    
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Function to open file dialog and get input/output video paths
def open_file_dialog():
    file_path = filedialog.askopenfilename(title="Select a Video", filetypes=[("MP4 files", "*.mp4")])
    return file_path

def save_file_dialog():
    file_path = filedialog.asksaveasfilename(defaultextension=".mp4", filetypes=[("MP4 files", "*.mp4")])
    return file_path

# Create the form UI
def create_form():
    root = tk.Tk()
    root.title("YTP Scrambling Generator")
    root.geometry("400x300")

    # Input file selection
    tk.Label(root, text="Input Video:").pack(pady=10)
    input_entry = tk.Entry(root, width=40)
    input_entry.pack(pady=5)
    input_button = tk.Button(root, text="Browse", command=lambda: input_entry.insert(0, open_file_dialog()))
    input_button.pack(pady=5)

    # Output file selection
    tk.Label(root, text="Output Video:").pack(pady=10)
    output_entry = tk.Entry(root, width=40)
    output_entry.pack(pady=5)
    output_button = tk.Button(root, text="Browse", command=lambda: output_entry.insert(0, save_file_dialog()))
    output_button.pack(pady=5)

    # Generate button
    generate_button = tk.Button(root, text="Generate Scrambled YTP", command=lambda: scramble_video(input_entry.get(), output_entry.get()))
    generate_button.pack(pady=20)

    root.mainloop()

# Run the form
if __name__ == "__main__":
    create_form()
