import random
import tkinter as tk
from tkinter import filedialog
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
from pydub import AudioSegment
from pydub.playback import play
import os

class YTPGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("YTP Generator 2010s Style")
        
        # File selection button
        self.select_button = tk.Button(root, text="Select Video", command=self.select_file)
        self.select_button.pack(pady=10)
        
        # Generate button
        self.generate_button = tk.Button(root, text="Generate YTP", command=self.generate_ytp)
        self.generate_button.pack(pady=10)
        
        # Label for status
        self.status_label = tk.Label(root, text="No video selected")
        self.status_label.pack(pady=20)
        
        self.video_file = None
        
    def select_file(self):
        self.video_file = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov")])
        if self.video_file:
            self.status_label.config(text="Selected: " + os.path.basename(self.video_file))
        else:
            self.status_label.config(text="No video selected")
    
    def generate_ytp(self):
        if not self.video_file:
            self.status_label.config(text="Please select a video file first")
            return
        
        # Load the selected video
        video_clip = VideoFileClip(self.video_file)
        
        # Split video into random short clips
        duration = video_clip.duration
        clips = []
        for _ in range(10):  # Generate 10 random clips
            start_time = random.uniform(0, duration - 2)  # Random start time
            clip_duration = random.uniform(0.5, 1.5)  # Random clip duration (between 0.5 and 1.5 seconds)
            clip = video_clip.subclip(start_time, start_time + clip_duration)
            
            # Apply random effects
            if random.choice([True, False]):
                clip = clip.fx(vfx.speedx, random.uniform(0.5, 2.0))  # Speed up/down
            if random.choice([True, False]):
                clip = clip.fx(vfx.mirror_x)  # Mirror horizontally
            if random.choice([True, False]):
                clip = clip.fx(vfx.colorx, random.uniform(0.5, 1.5))  # Random color brightness
            
            clips.append(clip)
        
        # Concatenate all clips into one video
        final_clip = concatenate_videoclips(clips)
        
        # Save the result
        output_file = "ytp_output.mp4"
        final_clip.write_videofile(output_file, codec="libx264")
        
        self.status_label.config(text="YTP generated: " + output_file)
    
    def apply_audio_effects(self, audio_file):
        # Load audio
        audio = AudioSegment.from_file(audio_file)
        
        # Apply random audio effects
        if random.choice([True, False]):
            audio = audio.reverse()  # Reverse audio
        if random.choice([True, False]):
            audio = audio.speedup(playback_speed=random.uniform(1.5, 2.0))  # Speed up audio
        if random.choice([True, False]):
            audio = audio + random.randint(-10, 10)  # Randomly increase/decrease volume
        
        # Save modified audio
        audio_output = "ytp_audio_output.wav"
        audio.export(audio_output, format="wav")
        play(audio)
        return audio_output

if __name__ == "__main__":
    root = tk.Tk()
    app = YTPGenerator(root)
    root.mainloop()
