from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
import numpy as np
import random

# Load the video file
video = VideoFileClip('input_video.mp4')

# Define the duration of each clip
clip_duration = 70  # seconds

# Create a list to store the clips
clips = []

# Randomly cut clips from the original video
for _ in range(10):  # number of clips
    start_time = random.uniform(0, video.duration - clip_duration)
    end_time = start_time + clip_duration
    clip = video.subclip(start_time, end_time)
    
    # Apply random effects
    if random.choice([True, False]):
        clip = clip.fx(vfx.colorx, 1.5)  # Increase color saturation
    if random.choice([True, False]):
        clip = clip.fx(vfx.mirror_x)  # Mirror horizontally
    if random.choice([True, False]):
        clip = clip.fx(vfx.rotate, angle=random.uniform(-45, 45))  # Random rotation
    
    clips.append(clip)

# Concatenate the clips into a single video
chaotic_video = concatenate_videoclips(clips)

# Write the result to a file
chaotic_video.write_videofile('chaotic_remix.mp4', codec='libx264')
