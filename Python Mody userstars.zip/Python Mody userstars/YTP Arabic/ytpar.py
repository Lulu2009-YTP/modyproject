from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx

# Load the video clip
clip = VideoFileClip("source_video.mp4")

# Apply edits: speed up, reverse, add effects
clip_reversed = clip.fx(vfx.time_mirror)
clip_sped_up = clip.fx(vfx.speedx, 2)

# Combine both edits into a single video
final_clip = concatenate_videoclips([clip, clip_reversed, clip_sped_up])

# Save the result
final_clip.write_videofile("ytpar_output.mp4", codec="libx264")
