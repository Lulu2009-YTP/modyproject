from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx
from pydub import AudioSegment
import numpy as np

# Load the video file
video = VideoFileClip("input_video.mp4")

# Example: Trim the video into two parts and concatenate
clip1 = video.subclip(0, 2)  # First 2 seconds
clip2 = video.subclip(2, 4)  # Next 2 seconds

# Apply a visual effect to the clip (Zoom in effect)
clip1_zoomed = clip1.fx(vfx.zoom_in, factor=1.5)

# Apply rotation effect to the second clip
clip2_rotated = clip2.rotate(45)

# Concatenate the clips with effects
final_video = concatenate_videoclips([clip1_zoomed, clip2_rotated])

# Load the audio file
audio = AudioSegment.from_file("input_audio.mp3")

# Apply a simple pitch shift (speed up audio by 10%)
shifted_audio = audio.speedup(playback_speed=1.1)

# Export final video (without audio)
final_video.write_videofile("output_video.mp4", codec="libx264")

# Save the manipulated audio separately
shifted_audio.export("output_audio.mp3", format="mp3")

# Combine the final video with manipulated audio
final_video = final_video.set_audio(AudioSegment.from_file("output_audio.mp3"))
final_video.write_videofile("final_output_with_audio.mp4", codec="libx264")
