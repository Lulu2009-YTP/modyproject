import random
from moviepy.editor import VideoFileClip, concatenate_videoclips, vfx, AudioFileClip
import os

def apply_random_effects(clip):
    """Applies a series of random YTP-style effects to the given clip."""
    effects = [
        lambda c: c.fx(vfx.time_mirror),  # Reverse clip
        lambda c: c.fx(vfx.speedx, 0.5),  # Slow motion
        lambda c: c.fx(vfx.speedx, 2),    # Fast motion
        lambda c: c.subclip(0, c.duration / 2),  # Cut the clip in half
        lambda c: c.fx(vfx.mirror_x),     # Mirror horizontally
        lambda c: c.fx(vfx.mirror_y),     # Mirror vertically
    ]
    # Apply a random effect from the list
    return random.choice(effects)(clip)

def insert_random_memes(video_clip, memes_dir, num_inserts=3):
    """Insert random meme clips from the meme directory into the video."""
    meme_files = [os.path.join(memes_dir, f) for f in os.listdir(memes_dir) if f.endswith('.mp4')]
    meme_clips = [VideoFileClip(meme) for meme in random.sample(meme_files, num_inserts)]
    
    # Get random insertion points
    insert_times = sorted([random.uniform(0, video_clip.duration) for _ in range(num_inserts)])
    
    final_clips = []
    start = 0
    for i, meme_clip in zip(insert_times, meme_clips):
        # Add part of the original video up to the insertion point
        final_clips.append(video_clip.subclip(start, i))
        # Add the meme clip
        final_clips.append(apply_random_effects(meme_clip))
        start = i
    
    # Add the rest of the original video
    final_clips.append(video_clip.subclip(start, video_clip.duration))
    
    return concatenate_videoclips(final_clips)

def create_ytp(input_video_path, memes_dir, output_path):
    """Generates a YouTube Poop (YTP) video."""
    video_clip = VideoFileClip(input_video_path)
    
    # Apply random effects to the entire clip
    video_clip = apply_random_effects(video_clip)
    
    # Insert random meme clips
    video_clip = insert_random_memes(video_clip, memes_dir)
    
    # Export the final video
    video_clip.write_videofile(output_path, codec="libx264", audio_codec="aac")

# Usage:
# create_ytp("input.mp4", "path_to_memes_folder", "output_ytp.mp4")
